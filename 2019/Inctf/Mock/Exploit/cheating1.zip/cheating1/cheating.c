#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int authenticate(){
	char default_password[512]="This_is_going_to_be_a_valid_password";
	char entered_password[512];
	fgets(entered_password,1025,stdin);
	if(strcmp(default_password,entered_password)==0){
		return 1;
	}
	else 
		return 0;
}
int main(){
	printf("\nHey there\nWelcome to PASS (Password Authentication Security System)\nPAS is very simple\nIt is very powerful also\n");
	int value=authenticate();
	if(value){
		printf("\nI guess its not so powerful after all\n");
		system("/bin/sh");
	}
	else{
		printf("\nSee, I told you PAS was powerful\n");
		return 0;
	}
}
